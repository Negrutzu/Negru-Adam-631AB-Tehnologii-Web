  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div>
        <strong>© <?php echo date('Y'); ?> Citate Motivaționale</strong>
        <p>Proiect demo — creat pentru inspirație și practică.</p>
      </div>
      <div class="footer-links">
        <a href="despre.php">Despre</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <script src="app.js"></script>
</body>
</html>
