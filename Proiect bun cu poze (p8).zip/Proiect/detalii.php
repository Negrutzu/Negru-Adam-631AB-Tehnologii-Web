<?php
$title = "Detalii citat";
include __DIR__ . '/inc/header.php';
include __DIR__ . '/inc/quotes_data.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 0 || $id >= count($QUOTES)) {
    echo "<div class='container'><p>Citat invalid.</p></div>";
    include __DIR__ . '/inc/footer.php';
    exit;
}
$q = $QUOTES[$id];
?>
<section class="detail">
  <div class="detail-card card">
    <p class="qtext large"><?php echo htmlspecialchars($q); ?></p>
    <div class="meta">
      <span>ID: <?php echo $id; ?></span>
      <span>Caractere: <?php echo strlen($q); ?></span>
    </div>
    <div class="quote-actions">
      <a class="btn" href="citate.php">Înapoi la listă</a>
      <?php if(in_array($id, $_SESSION['favorites'] ?? [])): ?>
        <a class="btn danger" href="citate.php?fav_remove=<?php echo $id; ?>">Elimină din favorite</a>
      <?php else: ?>
        <a class="btn" href="citate.php?fav_add=<?php echo $id; ?>">Adaugă la favorite</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/inc/footer.php'; ?>
