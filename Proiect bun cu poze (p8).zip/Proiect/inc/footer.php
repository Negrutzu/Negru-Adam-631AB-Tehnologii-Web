</main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div>
        <strong>© <?php echo date('Y'); ?> Citate Motivaționale</strong>
        <p>Proiect realizat pentru nota finală — cod clar, responsive și modular.</p>
      </div>
      <div class="footer-links">
        <a href="despre.php">Despre</a>
        <a href="contact.php">Contact</a>
      </div>
    </div>
  </footer>

  <!-- Back to top button -->
  <a href="#top" class="back-to-top" aria-label="Mergi sus">⬆️ Top</a>

  <script src="assets/js/app.js"></script>
</body>
</html>
