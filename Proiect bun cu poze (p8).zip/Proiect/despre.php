<?php $title = 'Despre'; include __DIR__ . '/inc/header.php'; ?>
<section class="about card">
  <h2>Despre proiect</h2>
  <p>Această colecție a fost creată pentru tema finală — include layout Grid, carduri Flexbox, responsive și UX curat.</p>
  <h3>Specificații tehnice</h3>
  <ul>
    <li>Header + Nav + Main + Aside + Footer aranjate cu CSS Grid</li>
    <li>Cardurile din secțiunea demonstrativă folosesc Flexbox</li>
    <li>Responsive @media pentru >900px și <900px</li>
    <li>Imagini redimensionate și centrate pe mobil</li>
    <li>Buton "Mergi sus" fixat</li>
  </ul>
</section>
<?php include __DIR__ . '/inc/footer.php'; ?>
