<?php include 'inc/header.php'; ?>

<section class="contact">
  <h2>Contact</h2>
  <p>Ai un citat preferat? Trimite-l și îl putem adăuga pe site!</p>
  <form>
    <input type="text" placeholder="Numele tău" required>
    <input type="email" placeholder="Emailul tău" required>
    <textarea placeholder="Scrie citatul tău aici..." required></textarea>
    <button type="submit">Trimite</button>
  </form>
</section>

<?php include 'inc/footer.php'; ?>
