<?php include 'inc/header.php'; ?>

<section class="about">
  <h2>Despre acest site</h2>
  <p>Acest proiect a fost creat pentru a aduce inspirație, motivație și o energie pozitivă tuturor celor care caută un impuls zilnic. Fiecare citat a fost selectat pentru a transmite un mesaj de curaj, perseverență și încredere în sine.</p>
  <p>Proiect realizat de <strong>Adam Negru</strong> — pasionat de tehnologie, design și idei care inspiră lumea.</p>
</section>

<?php include 'inc/footer.php'; ?>
