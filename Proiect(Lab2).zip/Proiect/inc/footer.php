  </main>
  <footer>
    <p>© <?php echo date('Y'); ?> Citate Motivaționale | Inspiră și fii mai bun în fiecare zi</p>
  </footer>
</body>
</html>
