<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Citate Motivaționale</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>🌟 Citate Motivaționale</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="citate.php">Citate</a>
      <a href="despre.php">Despre</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>
  <main>
