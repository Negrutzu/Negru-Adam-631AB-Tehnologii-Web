<?php include 'inc/header.php'; ?>

<h2>Toate citatele</h2>
<div class="quote-list">
<?php
$citate = [
"Viața este 10% ceea ce ți se întâmplă și 90% cum reacționezi. – Charles Swindoll",
"Succesul este suma micilor eforturi repetate zi de zi. – Robert Collier",
"Fiecare zi este o nouă șansă să îți schimbi viața.",
"Crede că poți și ești deja la jumătatea drumului. – Theodore Roosevelt",
"Nu renunța niciodată, pentru că niciodată nu știi cât de aproape ești de succes.",
"Fă azi ceea ce alții nu vor, ca mâine să trăiești cum alții nu pot.",
"Cel mai bun moment pentru a planta un copac a fost acum 20 de ani. Al doilea cel mai bun este acum.",
"Nu te opri când ești obosit. Oprește-te când ai terminat.",
"Visurile nu funcționează decât dacă muncești pentru ele.",
"Nu poți schimba direcția vântului, dar poți ajusta pânzele.",
"Oricine poate renunța, dar adevărata putere e în cel ce merge mai departe.",
"Începe de unde ești, folosește ce ai, fă ce poți. – Arthur Ashe",
"Fericirea nu este ceva gata făcut. Ea vine din propriile tale acțiuni. – Dalai Lama",
"Succesul este o călătorie, nu o destinație.",
"Fiecare eșec te aduce mai aproape de succes.",
"Nu te compara cu ceilalți. Compară-te cu tine însuți de ieri.",
"Nu există scurtături către locurile unde merită să ajungi.",
"Cel mai mare risc este să nu îți asumi niciun risc. – Mark Zuckerberg",
"În viață nu primești ceea ce meriți, ci ceea ce negociezi.",
"Fii curajos. Chiar dacă nu ești, prefă-te – și curajul va veni.",
"Fă ceea ce iubești și nu vei munci nicio zi din viața ta. – Confucius",
"Crede în tine și ești deja cu un pas înaintea tuturor.",
"Este imposibil doar până când devine posibil. – Nelson Mandela",
"Obstacolele sunt acele lucruri teribile pe care le vezi când îți iei ochii de la scop.",
"Fii recunoscător pentru ceea ce ai și vei avea mereu mai mult.",
"Perseverența este cheia succesului.",
"Succesul nu vine la cei care așteaptă, ci la cei care acționează.",
"Cel mai mare dușman al progresului este teama de eșec.",
"Curajul nu este absența fricii, ci victoria asupra ei.",
"Un om fără scop este ca o corabie fără cârmă.",
"Fii vocea ta, nu ecoul altora.",
"Învață din trecut, trăiește în prezent, visează la viitor.",
"Nu te opri niciodată din învățat.",
"Fericirea se construiește, nu se caută.",
"În fiecare zi ai șansa să devii o versiune mai bună a ta.",
"Motivația te pornește. Obiceiul te ține în mișcare.",
"Viața începe la sfârșitul zonei tale de confort.",
"Nu există succes fără disciplină.",
"Fă mai mult decât ești plătit, și în timp vei fi plătit mai mult decât faci.",
"Succesul nu este pentru cei slabi, ci pentru cei consecvenți.",
"Tot ceea ce îți imaginezi poate deveni realitate. – Walt Disney",
"Fiecare zi este o nouă oportunitate de a fi mai bun.",
"Nu-ți fie teamă de eșec. Fii speriat să nu încerci.",
"Învață regulile ca un profesionist, ca să le poți încălca ca un artist. – Picasso",
"Nu există limite, doar granițe auto-impuse.",
"Trăiește simplu, visează măreț, fii recunoscător.",
"Succesul se măsoară în câte vieți inspiri.",
"Zâmbește. Este cel mai simplu mod de a schimba o zi.",
"Fii lumina care inspiră pe alții să strălucească.",
"Lucrurile bune vin la cei care muncesc din greu.",
"Fiecare vis mare începe cu un visător curajos."
];

foreach ($citate as $c) {
  echo "<div class='quote-card'>$c</div>";
}
?>
</div>

<?php include 'inc/footer.php'; ?>
