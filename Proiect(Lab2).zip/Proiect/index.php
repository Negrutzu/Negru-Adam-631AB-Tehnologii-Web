<?php include 'inc/header.php'; ?>

<section class="hero">
  <h2>Descoperă puterea cuvintelor care inspiră.</h2>
  <p>Un citat bun îți poate schimba ziua. Sau viața.</p>
  <a href="citate.php" class="btn">Vezi toate citatele</a>
</section>

<section class="featured">
  <h3>Citate populare</h3>
  <div class="quote-grid">
    <?php
    $citate = [
      "Succesul nu este final, eșecul nu este fatal: curajul de a continua contează. – Winston Churchill",
      "Fii schimbarea pe care vrei să o vezi în lume. – Mahatma Gandhi",
      "Nimic nu este imposibil pentru o minte hotărâtă. – Napoleon Bonaparte",
      "Eșecul este doar oportunitatea de a începe din nou, mai inteligent. – Henry Ford",
      "Nu aștepta momentul perfect. Ia momentul și fă-l perfect. – Zoey Sayward"
    ];

    foreach ($citate as $c) {
      echo "<div class='quote-card'>$c</div>";
    }
    ?>
  </div>
</section>

<?php include 'inc/footer.php'; ?>
