<?php
$title = "Despre";
include __DIR__ . '/inc/header.php';
?>
<section class="about card">
  <h2>Despre proiect</h2>
  <p>Această colecție a fost creată pentru a oferi un loc curat, rapid și plăcut în care să găsești citate care te motivează. Codul este scris simplu, modular și ușor de extins.</p>
  <h3>Ce îți oferă acest site</h3>
  <ul>
    <li>50+ citate atent selecționate</li>
    <li>Design responsive și modern</li>
    <li>Sistem simplu de favorite</li>
    <li>Funcționalități de căutare și paginare</li>
  </ul>
</section>
<?php include __DIR__ . '/inc/footer.php'; ?>
