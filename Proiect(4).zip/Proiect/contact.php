<?php
$title = "Contact";
include __DIR__ . '/inc/header.php';

$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''));
    $msg = htmlspecialchars(trim($_POST['message'] ?? ''));
    // aici, în producție, ai valida și trimite email sau salva în DB
    $sent = true;
}
?>
<section class="contact card">
  <h2>Contact</h2>
  <?php if($sent): ?>
    <div class="notice success">Mulțumim, mesajul tău a fost primit (demo).</div>
  <?php endif; ?>
  <form method="post" action="contact.php" class="contact-form">
    <label>Nume<input type="text" name="name" required></label>
    <label>Email<input type="email" name="email" required></label>
    <label>Mesaj<textarea name="message" rows="6" required></textarea></label>
    <div>
      <button class="btn primary" type="submit">Trimite</button>
    </div>
  </form>
</section>
<?php include __DIR__ . '/inc/footer.php'; ?>
