<?php
// header.php - include asta la începutul fiecărei pagini
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$basePath = __DIR__ . '/../'; // folosit intern, nu e necesar pe site
function isActive($page) {
    $current = basename($_SERVER['PHP_SELF']);
    return $current === $page ? 'nav-link active' : 'nav-link';
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo isset($title) ? $title . ' | Citate Motivaționale' : 'Citate Motivaționale'; ?></title>

  <!-- Font Google (link local safe) -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a class="brand" href="index.php">
        <div class="logo">🌟</div>
        <div class="brand-text">
          <h1>Citate Motivaționale</h1>
          <small>Inspirație zilnică — idei care schimbă</small>
        </div>
      </a>

      <nav class="main-nav">
        <a class="<?php echo isActive('index.php'); ?>" href="index.php">Acasă</a>
        <a class="<?php echo isActive('citate.php'); ?>" href="citate.php">Citate</a>
        <a class="<?php echo isActive('despre.php'); ?>" href="despre.php">Despre</a>
        <a class="<?php echo isActive('contact.php'); ?>" href="contact.php">Contact</a>
        <a class="<?php echo isActive('citate.php') . ' favorites-link'; ?>" href="citate.php?view=favorites">Favorite (<?php echo isset($_SESSION['favorites'])?count($_SESSION['favorites']):0; ?>)</a>
      </nav>
    </div>
  </header>

  <main class="site-main container">
