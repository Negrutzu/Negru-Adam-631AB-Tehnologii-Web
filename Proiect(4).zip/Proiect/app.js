// app.js - behaviors simple
document.addEventListener('click', function(e){
  // example: future JS expansions (delegare)
});
