<?php
$title = "Acasă";
include __DIR__ . '/inc/header.php';
include __DIR__ . '/inc/quotes_data.php';

// show 3 featured random quotes
$featured = array_rand(array_flip($QUOTES), 3);
?>
<section class="hero">
  <div class="hero-inner">
    <h2>Găsește cuvintele care te ridică azi.</h2>
    <p>O colecție curată de citate motivaționale atent selectate — inspiră, meditează, acționează.</p>
    <div class="hero-cta">
      <a class="btn primary" href="citate.php">Vezi toate citatele</a>
      <a class="btn ghost" href="contact.php">Trimite un citat</a>
    </div>
  </div>
  <div class="hero-featured">
    <?php foreach ($featured as $q): ?>
      <div class="featured-quote card">
        <p class="qtext"><?php echo htmlspecialchars($q); ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="grid-overview">
  <div class="card">
    <h3>Filtre și căutare</h3>
    <p>Caută după cuvinte cheie în pagina Citate — ex: "succes", "curaj", "viață".</p>
    <a class="btn" href="citate.php">Caută citate</a>
  </div>
  <div class="card">
    <h3>Favorite</h3>
    <p>Salvează citatele preferate și revino la ele oricând.</p>
    <a class="btn" href="citate.php?view=favorites">Vezi favorite</a>
  </div>
  <div class="card">
    <h3>Trimite un citat</h3>
    <p>Ai un citat preferat? Trimite-l prin formularul de contact și îl putem adăuga manual.</p>
    <a class="btn" href="contact.php">Trimite</a>
  </div>
</section>

<?php include __DIR__ . '/inc/footer.php'; ?>
