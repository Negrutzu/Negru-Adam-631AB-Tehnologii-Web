<?php
session_start();
require_once __DIR__ . "/inc/db.php";
require_once __DIR__ . "/inc/utils.php";

if (!isset($_SESSION['logged']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$success = "";
$edit_mode = false;
$edit_data = ['id' => '', 'text' => '', 'autor' => ''];

if (isset($_GET['approve_id'])) {
    $req_id = intval($_GET['approve_id']);
    $stmt = $conn->prepare("SELECT text, autor FROM quote_requests WHERE id = ?");
    $stmt->bind_param("i", $req_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $ins = $conn->prepare("INSERT INTO citate (text, autor) VALUES (?, ?)");
        $ins->bind_param("ss", $row['text'], $row['autor']);
        $ins->execute();
        
        $del = $conn->prepare("DELETE FROM quote_requests WHERE id = ?");
        $del->bind_param("i", $req_id);
        $del->execute();
        $success = "Citat aprobat și publicat!";
    }
}

if (isset($_GET['reject_id'])) {
    $req_id = intval($_GET['reject_id']);
    $stmt = $conn->prepare("DELETE FROM quote_requests WHERE id = ?");
    $stmt->bind_param("i", $req_id);
    $stmt->execute();
    $success = "Propunere respinsă.";
}

if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT * FROM citate WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $edit_data = $row;
        $edit_mode = true;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = trim($_POST['text'] ?? '');
    $autor = trim($_POST['autor'] ?? 'Anonim');
    $id = intval($_POST['id'] ?? 0);

    if ($text) {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE citate SET text = ?, autor = ? WHERE id = ?");
            $stmt->bind_param("ssi", $text, $autor, $id);
            $success = $stmt->execute() ? "Citatul a fost actualizat!" : "Eroare.";
        } else {
            $stmt = $conn->prepare("INSERT INTO citate (text, autor) VALUES (?, ?)");
            $stmt->bind_param("ss", $text, $autor);
            $success = $stmt->execute() ? "Citatul a fost adăugat!" : "Eroare.";
        }
        if ($success) {
            $edit_mode = false;
            $edit_data = ['id' => '', 'text' => '', 'autor' => ''];
        }
    }
}

if (isset($_GET['delete_id'])) {
    $del_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM citate WHERE id = ?");
    $stmt->bind_param("i", $del_id);
    $success = $stmt->execute() ? "Citat șters." : "Eroare.";
}

$title = "Administrare Site";
include __DIR__ . "/inc/header.php";
?>

<section class="container">
  <h2>Panou de Control Admin</h2>
  <?php if($success): ?><div class="notice success"><?php echo $success; ?></div><?php endif; ?>

  <div class="card" style="margin-bottom:30px; border-left: 5px solid #2ecc71;">
    <h3>Citate în așteptare (Propuneri utilizatori)</h3>
    <table style="width:100%; border-collapse: collapse;">
      <thead>
        <tr style="text-align:left; border-bottom:1px solid #eee;">
          <th style="padding:10px;">De la</th>
          <th style="padding:10px;">Citat</th>
          <th style="padding:10px;">Acțiuni</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $requests = $conn->query("SELECT * FROM quote_requests ORDER BY id DESC");
        while($r = $requests->fetch_assoc()): ?>
          <tr style="border-bottom:1px solid #eee;">
            <td style="padding:10px;"><?php echo htmlspecialchars($r['nume']); ?><br><small><?php echo htmlspecialchars($r['email']); ?></small></td>
            <td style="padding:10px;">"<?php echo htmlspecialchars($r['text']); ?>"<br><strong>— <?php echo htmlspecialchars($r['autor']); ?></strong></td>
            <td style="padding:10px;">
              <a href="admin.php?approve_id=<?php echo $r['id']; ?>" class="btn small" style="background:#2ecc71; color:white;">Aprobă</a>
              <a href="admin.php?reject_id=<?php echo $r['id']; ?>" class="btn small danger">Respinge</a>
            </td>
          </tr>
        <?php endwhile; ?>
        <?php if($requests->num_rows == 0): ?> <tr><td colspan="3" style="padding:10px;">Nu există propuneri noi.</td></tr> <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card" style="margin-bottom:30px; border-top: 5px solid var(--accent);">
    <h3><?php echo $edit_mode ? "Editează Citatul #" . $edit_data['id'] : "Adaugă Citat Nou"; ?></h3>
    <form method="post" action="admin.php">
      <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
      <label>Textul Citatului</label>
      <textarea name="text" rows="4" style="width:100%; padding:10px; border-radius:8px; border:1px solid #ddd;" required><?php echo htmlspecialchars($edit_data['text']); ?></textarea>
      <label>Autor</label>
      <input type="text" name="autor" value="<?php echo htmlspecialchars($edit_data['autor']); ?>" style="margin-bottom:15px;">
      <div style="display:flex; gap:10px;">
        <button class="btn primary" type="submit"><?php echo $edit_mode ? "Salvează" : "Adaugă"; ?></button>
        <?php if($edit_mode): ?> <a href="admin.php" class="btn ghost">Anulează</a> <?php endif; ?>
      </div>
    </form>
  </div>

  <h3>Toate Citatele Publice</h3>
  <div class="card" style="overflow-x:auto; padding:0;">
    <table style="width:100%; border-collapse: collapse;">
      <thead style="background:#f8f9fa;">
        <tr>
          <th style="padding:15px; text-align:left;">ID</th>
          <th style="padding:15px; text-align:left;">Conținut</th>
          <th style="padding:15px; text-align:center;">Acțiuni</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $res = $conn->query("SELECT * FROM citate ORDER BY id DESC");
        while($row = $res->fetch_assoc()): ?>
        <tr style="border-top:1px solid #eee;">
          <td style="padding:15px;"><?php echo $row['id']; ?></td>
          <td style="padding:15px; font-style:italic;">
            "<?php echo htmlspecialchars(substr($row['text'], 0, 100)); ?>..."
            <br><small>— <?php echo htmlspecialchars($row['autor']); ?></small>
          </td>
          <td style="padding:15px; text-align:center; white-space:nowrap;">
            <a href="admin.php?edit_id=<?php echo $row['id']; ?>" class="btn small">Edit</a>
            <a href="admin.php?delete_id=<?php echo $row['id']; ?>" class="btn small danger" onclick="return confirm('Ștergi?')">Șterge</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</section>
<?php include __DIR__ . "/inc/footer.php"; ?>