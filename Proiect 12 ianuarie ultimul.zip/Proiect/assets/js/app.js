// app.js - enhances UI: mobile menu, smooth back-to-top, modal fetch, client-side filter, fav toggle via fetch
document.addEventListener('DOMContentLoaded', function(){

  // mobile burger
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.main-nav');
  if(burger && nav){
    burger.addEventListener('click', ()=> {
      if(nav.style.display === 'flex') nav.style.display = 'none';
      else nav.style.display = 'flex';
    });
  }

  // smooth back to top
  const back = document.querySelector('.back-to-top');
  if(back){
    back.addEventListener('click', function(e){
      e.preventDefault();
      window.scrollTo({top:0,behavior:'smooth'});
    });
  }

  // Client-side filter on citate page
  const clientFilterBtn = document.getElementById('client-filter-btn');
  const searchInput = document.getElementById('search-input');
  const quoteList = document.getElementById('quote-list');
  if(clientFilterBtn && searchInput && quoteList){
    clientFilterBtn.addEventListener('click', function(){
      const term = searchInput.value.trim().toLowerCase();
      const cards = Array.from(quoteList.querySelectorAll('.quote-card'));
      if(!term){
        cards.forEach(c=> c.style.display = '');
        return;
      }
      cards.forEach(c=>{
        const txt = c.getAttribute('data-quote').toLowerCase();
        c.style.display = txt.includes(term) ? '' : 'none';
      });
    });
  }

  // Detalii modal: intercept Detalii links and load content via fetch into a modal
  function createModal(){
    const m = document.createElement('div');
    m.id = 'quote-modal';
    m.innerHTML = '<div class="modal-backdrop"></div><div class="modal-content"><button class="close">×</button><div class="modal-body"></div></div>';
    document.body.appendChild(m);
    m.querySelector('.close').addEventListener('click', ()=> m.remove());
    m.querySelector('.modal-backdrop').addEventListener('click', ()=> m.remove());
    return m;
  }
  document.body.addEventListener('click', function(e){
    const det = e.target.closest('a[href^="detalii.php"]');
    if(det){
      e.preventDefault();
      const url = det.getAttribute('href');
      fetch(url).then(r=>r.text()).then(html=>{
        const modal = createModal();
        const body = modal.querySelector('.modal-body');
        // extract the part between <section class="detail"> ... </section>
        const match = html.match(/<section[\s\S]*?<\/section>/);
        body.innerHTML = match ? match[0] : html;
      }).catch(()=> alert('Eroare la încărcare detalii.'));
    }
  });

  // Favorite toggle via fetch (progressive: links still work if JS off)
  document.body.addEventListener('click', function(e){
    const fav = e.target.closest('.fav-toggle');
    if(fav){
      e.preventDefault();
      const href = fav.getAttribute('href');
      fetch(href, {method: 'GET', credentials: 'same-origin'}).then(r=>{
        // reload page to update favorites count/server state
        window.location.reload();
      });
    }
  });

});
