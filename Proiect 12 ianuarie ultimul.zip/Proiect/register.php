<?php
session_start();
require_once __DIR__ . '/inc/db.php'; 

$err = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    $pass2 = trim($_POST['password2'] ?? '');

    if (!$username || !$pass || !$pass2) {
        $err = "Completează toate câmpurile.";
    } elseif ($pass !== $pass2) {
        $err = "Parolele nu coincid.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $err = "Username există deja.";
        } else {
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");
            $stmt->bind_param("ss", $username, $hashed);
            
            if ($stmt->execute()) {
                $success = "Cont creat cu succes! Te poți autentifica.";
            } else {
                $err = "Eroare la crearea contului.";
            }
        }
    }
}

$title = "Register";
include __DIR__ . '/inc/header.php';
?>

<h2>Creare cont</h2>
<?php if ($err): ?><div class="notice danger"><?php echo $err; ?></div><?php endif; ?>
<?php if ($success): ?><div class="notice success"><?php echo $success; ?></div><?php endif; ?>

<form method="post" class="card" style="max-width:420px;margin:auto">
  <label>Nume utilizator</label>
  <input type="text" name="username" required>
  <label>Parola</label>
  <input type="password" name="password" required>
  <label>Confirmare parolă</label>
  <input type="password" name="password2" required>
  <button class="btn primary" type="submit">Înregistrează-te</button>
</form>

<?php include __DIR__ . '/inc/footer.php'; ?>