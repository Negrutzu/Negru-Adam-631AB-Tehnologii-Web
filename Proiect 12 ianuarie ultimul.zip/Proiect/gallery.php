<?php
$title = "Galerie";
include __DIR__ . '/inc/header.php';
?>

<h2>Galerie cu citate vizuale</h2>
<p>Aici sunt afișate imaginile tale cu citate. Toate au aceeași dimensiune și sunt aranjate frumos într-o grilă.</p>

<div class="gallery-grid">
    <?php
    $dir = __DIR__ . "/assets/images/gallery";
    $files = array_diff(scandir($dir), ['.', '..']);

    foreach ($files as $img):
        $path = "assets/images/gallery/" . $img;
    ?>
        <div class="gallery-item">
            <img src="<?php echo $path; ?>" alt="Citat imagine">
        </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/inc/footer.php'; ?>
