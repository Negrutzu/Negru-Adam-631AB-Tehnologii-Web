<?php
$host = 'db';

if (!isset($_SERVER['SERVER_SOFTWARE'])) {
    $host = '127.0.0.1';
}

$user = 'root';
$pass = 'tiger';
$db   = 'citate_db';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    $conn = new mysqli('127.0.0.1', $user, $pass, $db);
    if ($conn->connect_error) {
        die("Eroare conectare DB: " . $conn->connect_error);
    }
}

$conn->set_charset("utf8mb4");
?>