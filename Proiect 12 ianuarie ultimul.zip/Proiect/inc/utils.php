<?php
require_once __DIR__ . '/db.php';

function current_user() {
    return $_SESSION['user'] ?? null;
}

function get_user_id($username) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();
    if($row = $res->fetch_assoc()) return $row['id'];
    return null;
}

function is_admin() {
    if (!isset($_SESSION['user'])) return false;
    global $conn;
    $u = $_SESSION['user'];
    $stmt = $conn->prepare("SELECT role FROM users WHERE username = ?");
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        return $row['role'] === 'admin';
    }
    return false;
}

function add_fav_quote($username, $quote_id) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    $check = $conn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND quote_id = ?");
    $check->bind_param("ii", $uid, $quote_id);
    $check->execute();
    if ($check->get_result()->num_rows > 0) return true;

    $stmt = $conn->prepare("INSERT INTO user_favorites (user_id, quote_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $uid, $quote_id);
    return $stmt->execute();
}

function remove_fav_quote($username, $quote_id) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    $stmt = $conn->prepare("DELETE FROM user_favorites WHERE user_id = ? AND quote_id = ?");
    $stmt->bind_param("ii", $uid, $quote_id);
    return $stmt->execute();
}

function add_fav_image($username, $imgpath) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    $check = $conn->prepare("SELECT id FROM user_fav_images WHERE user_id = ? AND image_path = ?");
    $check->bind_param("is", $uid, $imgpath);
    $check->execute();
    if ($check->get_result()->num_rows > 0) return true;

    $stmt = $conn->prepare("INSERT INTO user_fav_images (user_id, image_path) VALUES (?, ?)");
    $stmt->bind_param("is", $uid, $imgpath);
    return $stmt->execute();
}

function remove_fav_image($username, $imgpath) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    $stmt = $conn->prepare("DELETE FROM user_fav_images WHERE user_id = ? AND image_path = ?");
    $stmt->bind_param("is", $uid, $imgpath);
    return $stmt->execute();
}
?>