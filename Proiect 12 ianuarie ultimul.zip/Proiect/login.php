<?php
session_start();
require_once __DIR__ . '/inc/db.php';

$err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userInput = trim($_POST['username'] ?? '');
    $passInput = trim($_POST['password'] ?? '');

    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $userInput);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($passInput, $row['password'])) {
            $_SESSION['logged'] = true;
            $_SESSION['user'] = $row['username'];
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            
            header('Location: index.php');
            exit;
        } else {
            $err = "Username sau parolă greșite.";
        }
    } else {
        $err = "Username sau parolă greșite.";
    }
}

$title = "Login";
include __DIR__ . '/inc/header.php';
?>

<h2>Autentificare</h2>
<?php if ($err) echo "<div class='notice danger'>$err</div>"; ?>

<form method="post" class="card" style="max-width:420px;margin:auto">
  <label>Username</label>
  <input name="username" required>
  <label>Parola</label>
  <input type="password" name="password" required>
  <button class="btn primary" type="submit">Login</button>
  <p style="margin-top:10px;text-align:center">Nu ai cont? <a href="register.php">Înregistrează-te</a></p>
</form>

<?php include __DIR__ . '/inc/footer.php'; ?>