// Așteaptă ca întreg conținutul HTML să fie încărcat înainte de a rula scriptul
document.addEventListener('DOMContentLoaded', function(){

  // Selectează butonul de meniu (burger) și navigația principală din HTML
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.main-nav');
  
  // Dacă ambele elemente există în pagină, adaugă un ascultător de evenimente pentru click
  if(burger && nav){
    burger.addEventListener('click', ()=> {
      // Schimbă starea display-ului între 'none' (ascuns) și 'flex' (vizibil)
      if(nav.style.display === 'flex') nav.style.display = 'none';
      else nav.style.display = 'flex';
    });
  }

  // Selectează butonul "Mergi sus"
  const back = document.querySelector('.back-to-top');
  if(back){
    back.addEventListener('click', function(e){
      e.preventDefault(); // Oprește comportamentul implicit al link-ului (să nu sară brusc)
      window.scrollTo({top:0,behavior:'smooth'}); // Derulează pagina lin până la coordonata 0 (sus)
    });
  }

  // Filtrare pe partea de client (fără a interoga baza de date din nou)
  const clientFilterBtn = document.getElementById('client-filter-btn');
  const searchInput = document.getElementById('search-input');
  const quoteList = document.getElementById('quote-list');
  
  if(clientFilterBtn && searchInput && quoteList){
    clientFilterBtn.addEventListener('click', function(){
      const term = searchInput.value.trim().toLowerCase(); // Ia termenul căutat și îl face cu litere mici
      const cards = Array.from(quoteList.querySelectorAll('.quote-card')); // Transformă lista de carduri într-un tablou
      
      // Dacă nu există text de căutare, arată toate cardurile
      if(!term){
        cards.forEach(c=> c.style.display = '');
        return;
      }
      
      // Parcurge fiecare card și verifică dacă textul citatului conține termenul căutat
      cards.forEach(c=>{
        const txt = c.getAttribute('data-quote').toLowerCase(); // Citește atributul 'data-quote' setat în HTML
        c.style.display = txt.includes(term) ? '' : 'none'; // Ascunde cardul dacă nu se potrivește
      });
    });
  }

  // Funcție care creează dinamic elementele HTML pentru o fereastră modală (pop-up)
  function createModal(){
    const m = document.createElement('div'); // Creează un div nou
    m.id = 'quote-modal';
    // Inserează structura ferestrei modale
    m.innerHTML = '<div class="modal-backdrop"></div><div class="modal-content"><button class="close">×</button><div class="modal-body"></div></div>';
    document.body.appendChild(m); // Adaugă modalul în document
    
    // Închide modalul la click pe butonul de închidere sau pe fundal
    m.querySelector('.close').addEventListener('click', ()=> m.remove());
    m.querySelector('.modal-backdrop').addEventListener('click', ()=> m.remove());
    return m;
  }

  // Interceptează click-urile pe link-urile de "Detalii" pentru a le încărca în modal
  document.body.addEventListener('click', function(e){
    const det = e.target.closest('a[href^="detalii.php"]'); // Verifică dacă s-a dat click pe un link de detalii
    if(det){
      e.preventDefault(); // Nu deschide pagina PHP direct în browser
      const url = det.getAttribute('href'); // Ia adresa paginii de detalii
      
      // Fetch: cere conținutul paginii de detalii de la server în mod asincron
      fetch(url).then(r=>r.text()).then(html=>{
        const modal = createModal();
        const body = modal.querySelector('.modal-body');
        // Folosește o expresie regulată (RegEx) pentru a extrage doar secțiunea cu detalii din HTML-ul primit
        const match = html.match(/<section[\s\S]*?<\/section>/);
        body.innerHTML = match ? match[0] : html; // Pune conținutul în modal
      }).catch(()=> alert('Eroare la încărcare detalii.')); // Tratează erorile de rețea
    }
  });

  // Gestionarea favoritelor prin Fetch (fără a naviga la altă pagină)
  document.body.addEventListener('click', function(e){
    const fav = e.target.closest('.fav-toggle'); // Detectează butoanele de adăugare/eliminare favorite
    if(fav){
      e.preventDefault(); // Previne acțiunea standard a link-ului
      const href = fav.getAttribute('href');
      // Trimite cererea către server în fundal
      fetch(href, {method: 'GET', credentials: 'same-origin'}).then(r=>{
        window.location.reload(); // Reîncarcă pagina pentru a actualiza starea butoanelor
      });
    }
  });

});