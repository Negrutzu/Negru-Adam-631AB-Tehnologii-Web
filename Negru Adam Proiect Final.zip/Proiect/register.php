<?php
// Pornește sesiunea pentru a putea lucra cu variabile de sesiune dacă este necesar.
session_start();

// Include fișierul de conexiune la baza de date din folderul 'inc'.
require_once __DIR__ . '/inc/db.php'; 

// Inițializează variabilele pentru mesaje de eroare și succes.
$err = "";
$success = "";

// Verifică dacă pagina a fost accesată prin trimiterea formularului (metoda POST).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Preia datele din formular, curățând spațiile de la început și sfârșit cu trim().
    $username = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    $pass2 = trim($_POST['password2'] ?? '');

    // Validare: Verifică dacă toate câmpurile obligatorii au fost completate.
    if (!$username || !$pass || !$pass2) {
        $err = "Completează toate câmpurile.";
    } 
    // Validare: Verifică dacă parola introdusă coincide cu cea din câmpul de confirmare.
    elseif ($pass !== $pass2) {
        $err = "Parolele nu coincid.";
    } 
    else {
        // Pas 1: Verifică dacă numele de utilizator ales nu este deja ocupat în baza de date.
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username); // "s" indică un singur parametru de tip string.
        $stmt->execute();
        
        // Dacă interogarea returnează cel puțin un rând, înseamnă că utilizatorul există deja.
        if ($stmt->get_result()->num_rows > 0) {
            $err = "Username există deja.";
        } else {
            // Pas 2: Securizează parola folosind un algoritm de hashing (BCRYPT implicit).
            // Nu salvăm NICIODATĂ parolele în format text clar (plain text).
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            
            // Pas 3: Inserează noul utilizator în baza de date cu rolul implicit de 'user'.
            $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");
            $stmt->bind_param("ss", $username, $hashed);
            
            // Execută inserarea și verifică dacă a avut loc cu succes.
            if ($stmt->execute()) {
                $success = "Cont creat cu succes! Te poți autentifica.";
            } else {
                $err = "Eroare la crearea contului.";
            }
        }
    }
}

// Definește titlul paginii și include antetul vizual.
$title = "Register";
include __DIR__ . '/inc/header.php';
?>

<h2>Creare cont</h2>

<?php if ($err): ?><div class="notice danger"><?php echo $err; ?></div><?php endif; ?>
<?php if ($success): ?><div class="notice success"><?php echo $success; ?></div><?php endif; ?>

<form method="post" class="card" style="max-width:420px;margin:auto">
  <label>Nume utilizator</label>
  <input type="text" name="username" required>
  
  <label>Parola</label>
  <input type="password" name="password" required>
  
  <label>Confirmare parolă</label>
  <input type="password" name="password2" required>
  
  <button class="btn primary" type="submit">Înregistrează-te</button>
</form>

<?php 
// Include subsolul paginii.
include __DIR__ . '/inc/footer.php'; 
?>