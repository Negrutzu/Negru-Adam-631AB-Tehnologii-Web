<?php
$title = "Acasă"; // Definește titlul paginii care va fi afișat în tab-ul browserului.
include __DIR__ . '/inc/header.php'; // Include antetul site-ului (meniul și configurările de bază).
require_once __DIR__ . '/inc/db.php'; // Conectează pagina la baza de date; folosește require pentru că este esențială.

// Interogare SQL pentru a selecta 3 citate aleatorii din baza de date pentru secțiunea de recomandări.
$sql = "SELECT * FROM citate ORDER BY RAND() LIMIT 3";
$result = $conn->query($sql); // Execută interogarea pe serverul de baza de date.
$featured = []; // Inițializează un tablou gol pentru a stoca citatele găsite.

if ($result) {
    // Parcurge setul de rezultate și adaugă fiecare rând ca tablou asociativ în variabila $featured.
    while($row = $result->fetch_assoc()) {
        $featured[] = $row;
    }
}
?>

<section class="layout-grid">
  <header class="hero">
    <div class="hero-inner card">
      <h2>Găsește cuvintele care te ridică azi.</h2>
      <p>O colecție curată de citate motivaționale atent selectate — inspiră, meditează, acționează.</p>
      <div class="hero-cta">
        <a class="btn primary" href="citate.php">Vezi toate citatele</a>
        <a class="btn ghost" href="contact.php">Trimite un citat</a>
      </div>
    </div>
    
    <aside class="hero-aside">
      <?php foreach($featured as $f): ?>
        <div class="card featured-quote">
          <p class="qtext">"<?php echo htmlspecialchars($f['text']); ?>"</p>
          <small style="display:block; margin-top:5px; color:#666">— <?php echo htmlspecialchars($f['autor']); ?></small>
        </div>
      <?php endforeach; ?>
    </aside>
  </header>

  <main class="main-content">
    <section class="card products">
      <h3>Secțiune demonstrativă (Flexbox)</h3>
      <p>Această secțiune demonstrează cerința de layout cu Flexbox pentru carduri.</p>
      
      <div class="product-row">
        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder1.jpg')"></div>
          <h4>Inspirație zilnică</h4>
          <p>Colecție vastă de cuvinte care te împing înainte.</p>
        </div>

        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder2.jpg')"></div>
          <h4>Favorite</h4>
          <p>Salvează-ți citatele preferate pentru a reveni rapid la ele.</p>
        </div>

        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder3.jpg')"></div>
          <h4>Trimite un citat</h4>
          <p>Ai un citat preferat? Trimite-l prin formularul de contact.</p>
        </div>
      </div>
    </section>
  </main>

  <aside class="sidebar">
    <div class="card">
      <h4>Despre autor</h4>
      <p>Adam Negru — pasionat de tehnologie și design.</p>
    </div>
    
    <div class="card">
      <h4>Ultimele adăugate</h4>
      <ul>
        <?php 
        // Interogare pentru a afișa ultimele 5 citate adăugate în bază (ordonate descrescător după ID).
        $res = $conn->query("SELECT text FROM citate ORDER BY id DESC LIMIT 5");
        while($r = $res->fetch_assoc()): ?>
          <li style="margin-bottom:8px;">"<?php echo htmlspecialchars(substr($r['text'], 0, 50)) . '...'; ?>"</li>
        <?php endwhile; ?>
      </ul>
    </div>
  </aside>

  <footer class="page-footer card">
    <p>Pagina creată pentru proiectul de Web — include Grid, Flexbox, Responsive.</p>
  </footer>
</section>

<?php include __DIR__ . '/inc/footer.php'; ?> ```

