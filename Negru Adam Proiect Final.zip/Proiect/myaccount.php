<?php
// Pornește sesiunea pentru a accesa datele despre utilizatorul logat.
session_start();

// Verifică dacă utilizatorul este autentificat; dacă nu, îl redirecționează forțat către pagina de login.
if (!isset($_SESSION['logged']) || !$_SESSION['logged']) {
    header('Location: login.php');
    exit; // Oprește execuția pentru a preveni încărcarea restului paginii pentru vizitatori neautorizați.
}

// Setează titlul paginii și include componentele de bază: antetul și conexiunea la baza de date.
$title = "Contul meu";
include __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/db.php'; 

// Preia ID-ul și numele utilizatorului din variabilele de sesiune salvate la logare.
$user_id = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['user'] ?? 'Utilizator';

// Definește o interogare SQL complexă care folosește JOIN pentru a lega tabelul de citate cu cel de favorite.
// Se selectează toate coloanele din 'citate' (c.*) unde ID-ul utilizatorului se potrivește în tabelul 'user_favorites'.
$sql = "SELECT c.* FROM citate c 
        JOIN user_favorites uf ON c.id = uf.quote_id 
        WHERE uf.user_id = ? 
        ORDER BY uf.id DESC";

// Pregătește interogarea pentru a preveni atacurile de tip SQL Injection.
$stmt = $conn->prepare($sql);
// Leagă ID-ul utilizatorului la parametrul "?" din interogare (tip integer "i").
$stmt->bind_param("i", $user_id);
$stmt->execute(); // Execută cererea către baza de date.
$result = $stmt->get_result(); // Obține setul de rezultate.

$favorites = [];
// Parcurge rezultatele și le stochează într-un tablou pentru a fi afișate ulterior.
while ($row = $result->fetch_assoc()) {
    $favorites[] = $row;
}
?>

<section class="container" style="max-width:800px; margin-top:20px;">
    <div class="card" style="text-align:center; margin-bottom:30px;">
        <div style="font-size:50px;">👤</div>
        <h2>Salut, <?php echo htmlspecialchars($username); ?>!</h2>
        <p style="color:#666;">Bine ai venit în panoul tău personal.</p>
        
        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <p><strong style="color:red;">Administrator</strong></p>
            <a href="admin.php" class="btn">Mergi la Panou Admin</a>
        <?php endif; ?>
    </div>

    <h3>Citatele tale favorite</h3>
    
    <?php if (empty($favorites)): ?>
        <div class="card notice">
            Nu ai adăugat încă niciun citat la favorite. 
            <a href="citate.php">Vezi lista de citate</a>
        </div>
    <?php else: ?>
        <div class="quote-list">
            <?php foreach ($favorites as $row): ?>
                <article class="quote-card card" style="border-left-color: #ffb020;">
                    <p class="qtext">"<?php echo htmlspecialchars($row['text']); ?>"</p>
                    <div class="autor" style="text-align:right; font-weight:bold; margin-bottom:10px;">
                        — <?php echo htmlspecialchars($row['autor']); ?>
                    </div>
                    <div class="quote-actions">
                        <a class="btn small" href="detalii.php?id=<?php echo $row['id']; ?>">Detalii</a>
                        <a class="btn small danger" href="citate.php?fav_remove=<?php echo $row['id']; ?>">Șterge</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</section>

<?php 
// Include subsolul paginii.
include __DIR__ . '/inc/footer.php'; 
?>