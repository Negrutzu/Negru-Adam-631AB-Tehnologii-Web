<?php
// Setează titlul paginii pentru a fi afișat în browser prin intermediul fișierului header.php.
$title = "Galerie"; 

// Include partea de sus a site-ului (antetul și meniul de navigare).
include __DIR__ . '/inc/header.php'; 
?>

<h2>Galerie cu citate vizuale</h2>
<p>Aici sunt afișate imaginile tale cu citate. Toate au aceeași dimensiune și sunt aranjate frumos într-o grilă.</p>

<div class="gallery-grid">
    <?php
    // Definește calea absolută către folderul de pe server unde sunt stocate imaginile galeriei.
    $dir = __DIR__ . "/assets/images/gallery"; 
    
    // scandir($dir) citește toate fișierele din folder; array_diff elimină referințele către directorul curent (.) și cel părinte (..).
    $files = array_diff(scandir($dir), ['.', '..']); 

    // Parcurge fiecare fișier găsit în folder pentru a-l afișa în pagină.
    foreach ($files as $img):
        // Construiește calea relativă către imagine pentru a fi utilizată în atributul 'src' al tag-ului <img>.
        $path = "assets/images/gallery/" . $img; 
    ?>
        <div class="gallery-item">
            <img src="<?php echo $path; ?>" alt="Citat imagine">
        </div>
    <?php 
    // Încheie bucla de parcurgere a fișierelor.
    endforeach; 
    ?>
</div>

<?php 
// Include partea de jos a site-ului, închizând tag-urile HTML și încărcând scripturile JavaScript.
include __DIR__ . '/inc/footer.php'; 
?>