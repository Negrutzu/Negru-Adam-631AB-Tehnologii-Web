<?php
$title = "Detalii citat"; // Setează titlul paginii pentru a fi preluat de header.php.
include __DIR__ . '/inc/header.php'; // Include antetul site-ului (conține session_start și meniul).
require_once __DIR__ . '/inc/db.php'; // Include conexiunea la baza de date. 

// Preia ID-ul din parametrul URL (?id=x). Folosește intval() pentru a forța valoarea să fie un număr întreg, prevenind injectările.
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Pregătește o instrucțiune SQL securizată pentru a selecta toate datele citatului cu ID-ul respectiv.
$stmt = $conn->prepare("SELECT * FROM citate WHERE id = ?");
$stmt->bind_param("i", $id); // Leagă variabila $id la semnul de întrebare ca fiind de tip integer ("i").
$stmt->execute(); // Execută interogarea.
$result = $stmt->get_result(); // Recuperează rezultatul interogării.

// Verifică dacă interogarea a returnat vreun rând; dacă nu, afișează un mesaj de eroare.
if ($result->num_rows === 0) {
    echo "<div class='container'><div class='notice danger'>Citat invalid sau inexistent.</div></div>";
    include __DIR__ . '/inc/footer.php'; // Include footer-ul și oprește execuția scriptului.
    exit;
}

// Extrage datele citatului sub formă de tablou asociativ.
$q = $result->fetch_assoc();
?>

<section class="detail">
  <div class="detail-card card">
    <p class="qtext large">"<?php echo htmlspecialchars($q['text']); ?>"</p>
    
    <div class="autor-large" style="text-align:right; font-size:1.2em; font-weight:bold; margin-bottom:20px;">
        — <?php echo htmlspecialchars($q['autor']); ?> </div>

    <div class="meta">
      <span>ID Bază de Date: <?php echo $q['id']; ?></span>
      <span>Dată adăugare: <?php echo $q['data_adaugarii']; ?></span>
    </div>

    <div class="quote-actions">
      <a class="btn" href="citate.php">Înapoi la listă</a>
      
      <?php if(in_array($q['id'], $_SESSION['favorites'] ?? [])): ?>
        <a class="btn danger" href="citate.php?fav_remove=<?php echo $q['id']; ?>">Elimină din favorite</a>
      <?php else: ?>
        <a class="btn" href="citate.php?fav_add=<?php echo $q['id']; ?>">Adaugă la favorite</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/inc/footer.php'; // Închide tag-urile HTML și include scripturile JS. ?>