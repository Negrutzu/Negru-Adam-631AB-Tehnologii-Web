<?php
// Definește numele serviciului de bază de date, 'db' fiind numele din Docker.
$host = 'db';

// Verifică dacă scriptul rulează în afara unui server web (ex: în terminal) pentru a folosi localhost.
if (!isset($_SERVER['SERVER_SOFTWARE'])) {
    $host = '127.0.0.1'; // Schimbă host-ul pe adresa IP locală a calculatorului.
}

// Setează datele de autentificare pentru baza de date (user, parola, nume DB).
$user = 'root';
$pass = 'tiger';
$db   = 'citate_db';

// Creează o conexiune nouă folosind obiectul MySQLi cu parametrii definiți.
$conn = new mysqli($host, $user, $pass, $db);

// Verifică dacă există vreo eroare de conexiune la baza de date.
if ($conn->connect_error) {
    // În caz de eroare, încearcă să se conecteze din nou folosind direct adresa locală.
    $conn = new mysqli('127.0.0.1', $user, $pass, $db);
    
    // Dacă nici a doua tentativă nu reușește, oprește programul și afișează eroarea.
    if ($conn->connect_error) {
        die("Eroare conectare DB: " . $conn->connect_error);
    }
}

// Configurează conexiunea să folosească UTF-8 pentru a afișa corect diacriticele și emoji-urile.
$conn->set_charset("utf8mb4");
?>