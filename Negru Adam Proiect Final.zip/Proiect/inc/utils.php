<?php
// Include fișierul de conexiune la baza de date folosind calea absolută a directorului curent.
require_once __DIR__ . '/db.php';

// Funcție care returnează numele utilizatorului logat din sesiune sau null dacă vizitatorul este anonim.
function current_user() {
    // Folosește operatorul null coalescing (??) pentru a verifica dacă cheia 'user' există în variabila superglobală $_SESSION.
    return $_SESSION['user'] ?? null;
}

// Funcție care preia ID-ul unic al unui utilizator din baza de date pe baza numelui de utilizator (username).
function get_user_id($username) {
    global $conn; // Accesează variabila de conexiune la baza de date definită în exterior (în db.php).
    // Pregătește o instrucțiune SQL (Prepared Statement) pentru a preveni atacurile de tip SQL Injection.
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    // Leagă variabila $username la semnul de întrebare din query, specificând că este de tip string ("s").
    $stmt->bind_param("s", $username);
    $stmt->execute(); // Trimite interogarea spre execuție în serverul MySQL.
    $res = $stmt->get_result(); // Recuperează setul de date rezultat în urma execuției.
    // Verifică dacă s-a găsit un rând și returnează valoarea coloanei 'id' ca tablou asociativ.
    if($row = $res->fetch_assoc()) return $row['id'];
    return null; // Returnează null dacă utilizatorul nu există în tabelul 'users'.
}

// Funcție care verifică dacă utilizatorul curent are drepturi de administrator.
function is_admin() {
    // Dacă în sesiune nu este setat un utilizator, înseamnă că nu este logat, deci nu poate fi admin.
    if (!isset($_SESSION['user'])) return false;
    global $conn;
    $u = $_SESSION['user']; // Salvează numele utilizatorului din sesiune.
    // Interoghează baza de date pentru a afla valoarea coloanei 'role' pentru acest utilizator.
    $stmt = $conn->prepare("SELECT role FROM users WHERE username = ?");
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        // Returnează true doar dacă valoarea din baza de date este exact șirul de caractere 'admin'.
        return $row['role'] === 'admin';
    }
    return false;
}

// Funcție pentru marcarea unui citat ca fiind favorit de către un utilizator specific.
function add_fav_quote($username, $quote_id) {
    global $conn;
    $uid = get_user_id($username); // Obține mai întâi ID-ul numeric al utilizatorului.
    if (!$uid) return false; // Dacă utilizatorul nu este valid, operațiunea eșuează.

    // Verifică dacă acest citat nu este deja în lista de favorite (pentru a evita erori de duplicate).
    $check = $conn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND quote_id = ?");
    $check->bind_param("ii", $uid, $quote_id); // "ii" înseamnă că ambii parametri sunt întregi (integer).
    $check->execute();
    // Dacă interogarea returnează cel puțin un rând, înseamnă că e deja favorit, deci returnăm succes fără inserare.
    if ($check->get_result()->num_rows > 0) return true;

    // Inserează o nouă legătură în tabelul 'user_favorites' (tabel de joncțiune între utilizatori și citate).
    $stmt = $conn->prepare("INSERT INTO user_favorites (user_id, quote_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $uid, $quote_id);
    return $stmt->execute(); // Returnează rezultatul operației de inserare (true/false).
}

// Funcție pentru eliminarea unui citat din lista de favorite.
function remove_fav_quote($username, $quote_id) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    // Șterge înregistrarea din tabelul 'user_favorites' unde ID-ul utilizatorului și cel al citatului se potrivesc.
    $stmt = $conn->prepare("DELETE FROM user_favorites WHERE user_id = ? AND quote_id = ?");
    $stmt->bind_param("ii", $uid, $quote_id);
    return $stmt->execute();
}

// Funcție similară cu add_fav_quote, dar dedicată imaginilor din galerie.
function add_fav_image($username, $imgpath) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    // Verifică dacă imaginea (identificată prin calea fișierului) este deja marcată ca favorită.
    $check = $conn->prepare("SELECT id FROM user_fav_images WHERE user_id = ? AND image_path = ?");
    $check->bind_param("is", $uid, $imgpath); // "is" - integer pentru ID și string pentru calea imaginii.
    $check->execute();
    if ($check->get_result()->num_rows > 0) return true;

    // Salvează calea imaginii în tabelul 'user_fav_images'.
    $stmt = $conn->prepare("INSERT INTO user_fav_images (user_id, image_path) VALUES (?, ?)");
    $stmt->bind_param("is", $uid, $imgpath);
    return $stmt->execute();
}

// Funcție pentru eliminarea unei imagini din lista de favorite.
function remove_fav_image($username, $imgpath) {
    global $conn;
    $uid = get_user_id($username);
    if (!$uid) return false;

    // Șterge legătura dintre utilizator și imaginea specificată din baza de date.
    $stmt = $conn->prepare("DELETE FROM user_fav_images WHERE user_id = ? AND image_path = ?");
    $stmt->bind_param("is", $uid, $imgpath);
    return $stmt->execute();
}
?>