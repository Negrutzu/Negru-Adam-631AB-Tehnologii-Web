<?php
session_start(); // Pornește sesiunea pentru a putea salva datele utilizatorului după logare.
require_once __DIR__ . '/inc/db.php'; // Include conexiunea la baza de date.

$err = ""; // Variabilă pentru stocarea mesajelor de eroare afișate utilizatorului.

// Verifică dacă pagina a fost accesată prin trimiterea formularului (metoda POST).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Preia datele din formular și elimină spațiile goale accidentale.
    $userInput = trim($_POST['username'] ?? '');
    $passInput = trim($_POST['password'] ?? '');

    // Pregătește o interogare securizată pentru a căuta utilizatorul în baza de date.
    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $userInput); // Leagă parametrul primit de la utilizator ca fiind un string ("s").
    $stmt->execute(); // Execută căutarea.
    $result = $stmt->get_result(); // Recuperează rezultatul.

    // Verifică dacă s-a găsit un utilizator cu acel nume.
    if ($row = $result->fetch_assoc()) {
        // password_verify() compară parola introdusă cu hash-ul securizat salvat în baza de date.
        if (password_verify($passInput, $row['password'])) {
            // Dacă parola e corectă, salvăm informațiile esențiale în variabila superglobală $_SESSION.
            $_SESSION['logged'] = true; // Marchează utilizatorul ca fiind autentificat.
            $_SESSION['user'] = $row['username']; // Salvează numele utilizatorului.
            $_SESSION['user_id'] = $row['id']; // Salvează ID-ul unic.
            $_SESSION['role'] = $row['role']; // Salvează rolul (user sau admin) pentru permisiuni.
            
            // Trimite utilizatorul către pagina principală.
            header('Location: index.php');
            exit; // Oprește execuția scriptului curent.
        } else {
            // Mesaj generic de eroare pentru securitate (nu spunem exact ce e greșit).
            $err = "Username sau parolă greșite.";
        }
    } else {
        $err = "Username sau parolă greșite.";
    }
}

$title = "Login"; // Setează titlul ferestrei.
include __DIR__ . '/inc/header.php'; // Include structura vizuală de sus a site-ului.
?>

<h2>Autentificare</h2>
<?php if ($err) echo "<div class='notice danger'>$err</div>"; ?>

<form method="post" class="card" style="max-width:420px;margin:auto">
  <label>Username</label>
  <input name="username" required> <label>Parola</label>
  <input type="password" name="password" required> <button class="btn primary" type="submit">Login</button>
  <p style="margin-top:10px;text-align:center">Nu ai cont? <a href="register.php">Înregistrează-te</a></p>
</form>

<?php include __DIR__ . '/inc/footer.php'; // Include subsolul site-ului. ?>