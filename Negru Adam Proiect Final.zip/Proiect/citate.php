<?php
$title = "Citate"; // Setează titlul paginii pentru a fi folosit în header.
include __DIR__ . '/inc/header.php'; // Include partea superioară a site-ului.
include __DIR__ . '/inc/db.php'; // Include conexiunea la baza de date.

// Inițializează tabloul de favorite în sesiune dacă acesta nu există deja.
if (!isset($_SESSION['favorites'])) $_SESSION['favorites'] = [];

// Verifică dacă s-a primit o cerere prin GET pentru a adăuga un citat la favorite.
if (isset($_GET['fav_add'])) {
    $id = intval($_GET['fav_add']); // Convertește ID-ul primit în număr întreg pentru siguranță.
    // Adaugă ID-ul în sesiune doar dacă nu este deja prezent.
    if (!in_array($id, $_SESSION['favorites'])) $_SESSION['favorites'][] = $id;
    header('Location: citate.php'); // Reîncarcă pagina pentru a curăța parametrii din URL.
    exit; // Oprește execuția restului scriptului.
}

// Verifică dacă s-a primit o cerere prin GET pentru a elimina un citat de la favorite.
if (isset($_GET['fav_remove'])) {
    $id = intval($_GET['fav_remove']);
    // Filtrează tabloul de favorite, păstrând doar ID-urile care NU se potrivesc cu cel primit.
    $_SESSION['favorites'] = array_filter($_SESSION['favorites'], fn($v)=>$v!==$id);
    header('Location: citate.php');
    exit;
}

// Preia termenul de căutare și filtrul de vizualizare (toate sau doar favorite) din URL.
$search = trim($_GET['q'] ?? '');
$view = $_GET['view'] ?? '';

// Construiește clauza WHERE de bază pentru interogarea SQL.
$whereClause = "WHERE 1=1";
$params = []; // Tablou pentru parametrii folosiți în Prepared Statements.
$types = ""; // Șir de caractere care definește tipul datelor (s pentru string, i pentru integer).

// Adaugă condiția de căutare în SQL dacă utilizatorul a introdus un text.
if ($search !== '') {
    $whereClause .= " AND (text LIKE ? OR autor LIKE ?)"; // Caută parțial atât în text cât și în autor.
    $searchTerm = "%" . $search . "%"; // Wildcard-ul % permite potrivirea textului oriunde în interiorul șirului.
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "ss"; // Două string-uri.
}

// Dacă utilizatorul a selectat vizualizarea favoritelor, filtrează rezultatele după ID-urile din sesiune.
if ($view === 'favorites') {
    if (!empty($_SESSION['favorites'])) {
        // Convertește tabloul de ID-uri într-o listă separată prin virgulă pentru SQL.
        $fav_ids = implode(',', array_map('intval', $_SESSION['favorites']));
        $whereClause .= " AND id IN ($fav_ids)";
    } else {
        $whereClause .= " AND 1=0"; // Dacă nu are favorite, forțează returnarea a zero rezultate.
    }
}

// Logica de paginare: calculează pagina curentă și de unde începe afișarea.
$page = max(1, intval($_GET['page'] ?? 1)); // Asigură că pagina minimă este 1.
$perPage = 12; // Numărul de citate afișate pe o pagină.
$offset = ($page - 1) * $perPage; // Calculează de la al câtelea rând începe citirea din DB.

// Numără totalul de rezultate filtrate pentru a calcula numărul de pagini.
$countSql = "SELECT COUNT(*) as total FROM citate $whereClause";
$stmt = $conn->prepare($countSql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params); // Leagă dinamic parametrii de căutare.
}
$stmt->execute();
$totalResult = $stmt->get_result()->fetch_assoc();
$totalFiltered = $totalResult['total']; // Numărul total de rânduri găsite.
$pages = max(1, ceil($totalFiltered / $perPage)); // Calculează numărul total de pagini necesare.

// Interogarea finală pentru a prelua doar datele necesare paginii curente (folosind LIMIT și OFFSET).
$sql = "SELECT * FROM citate $whereClause ORDER BY id DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types .= "ii"; // Adaugă două numere întregi la finalul tipurilor.

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
// Parcurge rezultatele și le stochează într-un tablou pentru afișare.
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}
?>

<section class="list-header">
  <h2>Toate citatele</h2>
  <form class="search-form" method="get" action="citate.php">
    <input name="q" id="search-input" placeholder="Caută (ex: succes, Steve Jobs)" value="<?php echo htmlspecialchars($search); ?>">
    <?php if($view === 'favorites'): ?>
      <input type="hidden" name="view" value="favorites">
    <?php endif; ?>
    <button class="btn" type="submit">Caută</button>
    <a href="citate.php" class="btn ghost">Resetează</a>
  </form>
</section>

<section class="quote-list" id="quote-list">
  <?php if(empty($items)): ?>
    <div class="empty card">Nu s-au găsit citate în baza de date.</div>
  <?php else: ?>
    <?php foreach($items as $row): ?>
      <article class="quote-card card">
        <p class="qtext">"<?php echo htmlspecialchars($row['text']); ?>"</p>
        <div class="autor" style="text-align:right; font-weight:bold; margin-bottom:10px;">
            — <?php echo htmlspecialchars($row['autor'] ?? 'Anonim'); ?>
        </div>
        
        <div class="quote-actions">
          <a class="btn small" href="detalii.php?id=<?php echo $row['id']; ?>">Detalii</a>

          <?php if(in_array($row['id'], $_SESSION['favorites'] ?? [])): ?>
            <a class="btn small danger" href="citate.php?fav_remove=<?php echo $row['id']; ?>">Elimină Fav</a>
          <?php else: ?>
            <a class="btn small" href="citate.php?fav_add=<?php echo $row['id']; ?>">Adaugă Fav</a>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<?php if($pages > 1): ?>
  <nav class="pagination">
    <?php for($p=1;$p<=$pages;$p++): ?>
      <a class="page-link <?php echo $p==$page ? 'active' : ''; ?>" 
         href="citate.php?page=<?php echo $p; ?>&q=<?php echo urlencode($search); ?><?php echo $view==='favorites' ? '&view=favorites':''; ?>">
         <?php echo $p; ?>
      </a>
    <?php endfor; ?>
  </nav>
<?php endif; ?>

<?php include __DIR__ . '/inc/footer.php'; // Include partea inferioară a site-ului. ?>