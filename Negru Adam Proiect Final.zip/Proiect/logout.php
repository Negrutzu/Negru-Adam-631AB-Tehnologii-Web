<?php
session_start(); // Accesează sesiunea curentă a utilizatorului pentru a o putea închide.

session_destroy(); // Șterge definitiv fișierul de sesiune de pe server, eliminând toate datele salvate (username, rol etc.).

header('Location: index.php'); // Redirecționează utilizatorul automat către pagina de pornire după deconectare.

exit; // Oprește imediat execuția scriptului pentru a asigura securitatea și a preveni rularea codului accidental.