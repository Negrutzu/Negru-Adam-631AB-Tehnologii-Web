<?php
$title = 'Contact'; // Setează titlul paginii pentru a fi afișat în tab-ul browserului prin header.php.
include __DIR__ . '/inc/header.php'; // Include structura de sus a site-ului și meniul.
require_once __DIR__ . '/inc/db.php'; // Conectează scriptul la baza de date MySQL.
$sent = false; // Variabilă de control care ne indică dacă mesajul a fost salvat cu succes în baza de date.

// Verifică dacă pagina a fost accesată prin trimiterea formularului (metoda POST).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Preia și curăță datele introduse de utilizator.
  // trim() elimină spațiile inutile de la început și sfârșit.
  // htmlspecialchars() transformă caracterele speciale în entități HTML pentru a preveni atacurile de tip XSS.
  $name = htmlspecialchars(trim($_POST['name'] ?? ''));
  $email = htmlspecialchars(trim($_POST['email'] ?? ''));
  $message = htmlspecialchars(trim($_POST['message'] ?? ''));
  $autor = htmlspecialchars(trim($_POST['autor'] ?? 'Anonim')); // Dacă autorul lipsește, se folosește 'Anonim'.

  // Pregătește o instrucțiune SQL securizată pentru inserarea propunerii în tabelul quote_requests.
  $stmt = $conn->prepare("INSERT INTO quote_requests (nume, email, text, autor) VALUES (?, ?, ?, ?)");
  
  // Leagă variabilele de semnele de întrebare din query. "ssss" indică faptul că toți cei 4 parametri sunt de tip string.
  $stmt->bind_param("ssss", $name, $email, $message, $autor);
  
  // Execută comanda SQL. Dacă reușește, schimbăm starea variabilei $sent în true.
  if ($stmt->execute()) {
      $sent = true;
  }
}
?>

<section class="contact card">
  <h2>Trimite un citat pentru verificare</h2>
  
  <?php if($sent): ?>
    <div class="notice success">Citatul a fost trimis și va fi verificat de un administrator!</div>
  <?php endif; ?>

  <form class="contact-form" method="post" action="contact.php">
    <label>Numele tău<input type="text" name="name" required></label>
    <label>Email<input type="email" name="email" required></label>
    <label>Text Citat<textarea name="message" rows="4" required></textarea></label>
    <label>Autorul citatului<input type="text" name="autor"></label>
    
    <div><button class="btn primary" type="submit">Trimite propunerea</button></div>
  </form>
</section>

<?php include __DIR__ . '/inc/footer.php'; // Include subsolul și scripturile finale. ?>