<?php
session_start();

if (!isset($_SESSION['logged'])) {
    header("Location: login.php");
    exit;
}

$title = "Panou Admin";
include __DIR__ . "/inc/header.php";
?>

<h2>Bun venit în panoul de administrare!</h2>
<p>Aici poți adăuga funcționalități extra: citate noi, upload imagini etc.</p>

<a class="btn danger" href="logout.php">Logout</a>

<?php include __DIR__ . "/inc/footer.php"; ?>
