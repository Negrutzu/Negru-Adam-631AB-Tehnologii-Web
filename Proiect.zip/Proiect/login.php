<?php
session_start();
require_once __DIR__ . '/inc/utils.php';
$usersFile = 'users.json';
$users = load_json($usersFile);
$err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    foreach ($users as $u) {
        if ($u['username'] === $user && password_verify($pass, $u['password'])) {
            $_SESSION['logged'] = true;
            $_SESSION['user'] = $u['username'];
            header('Location: index.php');
            exit;
        }
    }
    $err = "Username sau parolă greșite.";
}

$title = "Login";
include __DIR__ . '/inc/header.php';
?>
<h2>Autentificare</h2>
<?php if ($err) echo "<div class='notice danger'>$err</div>"; ?>
<form method="post" class="card" style="max-width:420px;margin:auto">
  <label>Username</label>
  <input name="username" required>
  <label>Parola</label>
  <input type="password" name="password" required>
  <button class="btn primary" type="submit">Login</button>
  <p style="margin-top:10px;text-align:center">Nu ai cont? <a href="register.php">Înregistrează-te</a></p>
</form>
<?php include __DIR__ . '/inc/footer.php'; ?>
