<?php
// inc/utils.php - helper JSON + user utilities
function dataPath($file) {
    return __DIR__ . "/../data/" . $file;
}

function load_json($file) {
    $p = dataPath($file);
    if (!file_exists($p)) return [];
    $txt = file_get_contents($p);
    $json = json_decode($txt, true);
    return $json === null ? [] : $json;
}

function save_json($file, $data) {
    $p = dataPath($file);
    $tmp = $p . ".tmp";
    $fp = fopen($tmp, 'w');
    if ($fp === false) return false;
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    fclose($fp);
    rename($tmp, $p);
    return true;
}

function find_user_index($users, $username) {
    foreach ($users as $i => $u) {
        if (isset($u['username']) && $u['username'] === $username) return $i;
    }
    return -1;
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_admin() {
    if (!isset($_SESSION['user'])) return false;
    $users = load_json('users.json');
    $idx = find_user_index($users, $_SESSION['user']);
    if ($idx === -1) return false;
    return isset($users[$idx]['role']) && $users[$idx]['role'] === 'admin';
}

// Favorite management: quotes (store favorite quote IDs) and images (store image path)
function add_fav_quote($username, $quote_id) {
    $users = load_json('users.json');
    $i = find_user_index($users, $username);
    if ($i === -1) return false;
    if (!isset($users[$i]['favorites'])) $users[$i]['favorites'] = [];
    if (!in_array($quote_id, $users[$i]['favorites'])) {
        $users[$i]['favorites'][] = $quote_id;
        save_json('users.json', $users);
    }
    return true;
}
function remove_fav_quote($username, $quote_id) {
    $users = load_json('users.json');
    $i = find_user_index($users, $username);
    if ($i === -1) return false;
    $users[$i]['favorites'] = array_values(array_filter($users[$i]['favorites'] ?? [], fn($v) => $v != $quote_id));
    save_json('users.json', $users);
    return true;
}

function add_fav_image($username, $imgpath) {
    $users = load_json('users.json');
    $i = find_user_index($users, $username);
    if ($i === -1) return false;
    if (!isset($users[$i]['fav_images'])) $users[$i]['fav_images'] = [];
    if (!in_array($imgpath, $users[$i]['fav_images'])) {
        $users[$i]['fav_images'][] = $imgpath;
        save_json('users.json', $users);
    }
    return true;
}
function remove_fav_image($username, $imgpath) {
    $users = load_json('users.json');
    $i = find_user_index($users, $username);
    if ($i === -1) return false;
    $users[$i]['fav_images'] = array_values(array_filter($users[$i]['fav_images'] ?? [], fn($v) => $v !== $imgpath));
    save_json('users.json', $users);
    return true;
}
