// script.js - interactivitate pentru sortare, filtrare, formular și servicii dinamice

document.addEventListener('DOMContentLoaded', function(){
  // Sortare după durata (simplă)
  const sortBtn = document.getElementById('sortDurata');
  const table = document.getElementById('schedule');
  sortBtn && sortBtn.addEventListener('click', ()=>{
    const tbody = table.tBodies[0];
    const rows = Array.from(tbody.rows);
    rows.sort((a,b)=> Number(a.cells[3].textContent) - Number(b.cells[3].textContent));
    rows.forEach(r=>tbody.appendChild(r));
  });

  // Filtrare >5h
  const filterBtn = document.getElementById('filterLong');
  const resetBtn = document.getElementById('resetFilter');
  filterBtn && filterBtn.addEventListener('click', ()=>{
    const tbody = table.tBodies[0];
    Array.from(tbody.rows).forEach(row=>{
      const dur = Number(row.cells[3].textContent);
      row.style.display = dur>5 ? '' : 'none';
    });
  });
  resetBtn && resetBtn.addEventListener('click', ()=>{
    Array.from(table.tBodies[0].rows).forEach(r=>r.style.display='');
  });

  // Formular înscriere - validare simplă și mesaj
  const form = document.getElementById('signup');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      // validări simple native + feedback
      if(!form.checkValidity()){
        form.reportValidity();
        return;
      }
      const msg = document.getElementById('formMessage');
      msg.className='';
      msg.textContent = 'Înscriere primită! Veți fi contactat în curând.';
      msg.classList.remove('sr-only');
    });
  }

  // Formular clinic - adăugare serviciu personalizat
  const addService = document.getElementById('addService');
  const checkboxes = document.querySelector('.checkboxes');
  if(addService && checkboxes){
    addService.addEventListener('click', ()=>{
      const name = prompt('Nume serviciu nou (scurt):');
      if(name && name.trim().length>1){
        const id = 'svc_'+Date.now();
        const wrapper = document.createElement('label');
        wrapper.innerHTML = '<input type="checkbox" name="services" value="'+name+'"> '+name;
        checkboxes.insertBefore(wrapper, addService);
      }
    });
  }

  // Form clinic - submit (simulat)
  const vetForm = document.getElementById('vetForm');
  const msgBox = document.getElementById('msg');
  if(vetForm){
    vetForm.addEventListener('submit', function(e){
      e.preventDefault();
      if(!vetForm.checkValidity()){
        vetForm.reportValidity();
        return;
      }
      msgBox.hidden = false;
      msgBox.textContent = 'Formular trimis — vei primi confirmare în 24h.';
      vetForm.reset();
    });
  }
});