// script_pro.js - features: dark/light, table sort/filter, modal gallery, form handling, file preview
document.addEventListener('DOMContentLoaded', ()=>{
  const body = document.body;
  const themeBtn = document.getElementById('toggleTheme');
  const galleryBtn = document.getElementById('openGallery');
  const modal = document.getElementById('modal');
  const modalImg = document.getElementById('modalImg');
  const modalCaption = document.getElementById('modalCaption');
  const closeModal = document.getElementById('closeModal');

  // Initialize theme from localStorage or prefers-color-scheme
  const saved = localStorage.getItem('lab2_theme');
  if(saved) body.className = saved;
  else if(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) body.classList.add('theme-dark');
  else body.classList.add('theme-light');

  themeBtn && themeBtn.addEventListener('click', ()=>{
    if(body.classList.contains('theme-dark')){
      body.classList.remove('theme-dark'); body.classList.add('theme-light');
      themeBtn.setAttribute('aria-pressed','false');
      localStorage.setItem('lab2_theme','theme-light');
    } else {
      body.classList.remove('theme-light'); body.classList.add('theme-dark');
      themeBtn.setAttribute('aria-pressed','true');
      localStorage.setItem('lab2_theme','theme-dark');
    }
  });

  // Modal gallery
  const figures = document.querySelectorAll('.gallery-grid figure');
  figures.forEach(fig=>{
    fig.addEventListener('click', ()=> openModal(fig));
    fig.addEventListener('keydown', (e)=>{ if(e.key==='Enter') openModal(fig); });
  });
  function openModal(fig){
    const img = fig.querySelector('img').src;
    const caption = fig.querySelector('figcaption').textContent;
    modalImg.src = img; modalCaption.textContent = caption;
    modal.setAttribute('aria-hidden','false');
  }
  closeModal.addEventListener('click', ()=> modal.setAttribute('aria-hidden','true'));
  modal.addEventListener('click', (e)=>{ if(e.target===modal) modal.setAttribute('aria-hidden','true'); });

  // Table sort & filter
  const table = document.getElementById('schedule');
  const sortBtn = document.getElementById('sortDur');
  const filterBtn = document.getElementById('filterLong');
  const clearBtn = document.getElementById('clearFilters');
  const search = document.getElementById('search');
  if(sortBtn){
    sortBtn.addEventListener('click', ()=>{
      const tbody = table.tBodies[0];
      const rows = Array.from(tbody.rows);
      const dir = sortBtn.dataset.dir === 'asc' ? 1 : -1;
      rows.sort((a,b)=> dir*(Number(a.cells[3].textContent)-Number(b.cells[3].textContent)));
      rows.forEach(r=>tbody.appendChild(r));
      sortBtn.dataset.dir = dir===1 ? 'desc':'asc';
      sortBtn.textContent = dir===1 ? 'Sortează durata ▼':'Sortează durata ▲';
    });
  }
  if(filterBtn){
    filterBtn.addEventListener('click', ()=>{
      Array.from(table.tBodies[0].rows).forEach(r=>{
        const dur = Number(r.cells[3].textContent);
        r.style.display = dur>5 ? '' : 'none';
      });
    });
  }
  clearBtn && clearBtn.addEventListener('click', ()=> Array.from(table.tBodies[0].rows).forEach(r=>r.style.display=''));
  search && search.addEventListener('input', (e)=>{
    const q = e.target.value.toLowerCase();
    Array.from(table.tBodies[0].rows).forEach(r=>{
      const txt = r.cells[1].textContent.toLowerCase();
      r.style.display = txt.includes(q) ? '' : 'none';
    });
  });

  // Signup form handling + file preview
  const signup = document.getElementById('signupForm');
  const signupMsg = document.getElementById('signupMsg');
  const foto = document.getElementById('foto');
  if(foto){
    foto.addEventListener('change', (e)=>{
      const f = e.target.files[0];
      if(!f) return;
      if(!f.type.startsWith('image/')){ alert('Încarcă doar imagini.'); foto.value=''; return; }
      // Preview modal
      const url = URL.createObjectURL(f);
      const prev = document.createElement('img'); prev.src = url; prev.style.maxWidth='120px'; prev.style.display='block'; prev.style.marginTop='8px';
      if(foto.nextSibling) foto.parentNode.removeChild(foto.nextSibling);
      foto.parentNode.insertBefore(prev, foto.nextSibling);
    });
  }
  signup && signup.addEventListener('submit', (e)=>{
    e.preventDefault();
    if(!signup.checkValidity()){ signup.reportValidity(); return; }
    signupMsg.className='msg'; signupMsg.textContent = 'Înscriere primită — vei primi confirmare.';
    signup.reset();
    setTimeout(()=>{ signupMsg.className='sr-only'; signupMsg.textContent=''; }, 5000);
  });
});