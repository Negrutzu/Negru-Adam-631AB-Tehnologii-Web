Lab2 PRO MAX - pachet pentru Moodle
Conține:
- programExcursie_pro.html
- css/program_pro.css
- css/inregistrare_pro.css
- js/script_pro.js
- images/ (placeholder SVGs)

Instrucțiuni imagini locale:
1. În folderul 'images/' sunt placeholder-uri SVG: mountain1.svg, mountain2.svg, mountain3.svg, pet1.svg, pet2.svg, pet3.svg.
2. Pentru imagini reale folosește surse gratuite (Unsplash / Pexels). Exemplu linkuri Unsplash recomandate:
   - https://unsplash.com/photos/eOpewngf68w   -> mountain1.jpg
   - https://unsplash.com/photos/tGTVxeOr_Rs   -> mountain2.jpg
   - https://unsplash.com/photos/4_jhDO54BYg   -> mountain3.jpg
   - https://unsplash.com/photos/JUoG7CjU-yA   -> pet1.jpg
   - https://unsplash.com/photos/1Hqf4B0Uneg   -> pet2.jpg
   - https://unsplash.com/photos/EUO3a4EZ_0w   -> pet3.jpg

3. Salvează imaginile descărcate în folderul 'images/' și redenumește-le exact ca fișierele placeholder (ex: mountain1.jpg).
4. Daca păstrezi extensia .jpg, actualizează src-urile din HTML la .jpg (sau păstrează aceleași nume). Locurile în care sunt folosite: galerii & hero images din programExcursie_pro.html
5. Deschide programExcursie_pro.html în browser — totul va funcționa offline.

Personalizare:
- Vrei altă paletă de culori sau animații? Spune-mi și îți generez o variantă (dark-heavy, minimal, sau "photo-first").

Arhiva generată: 631AB_Negru_Adam_Lab2_PRO_MAX.zip
