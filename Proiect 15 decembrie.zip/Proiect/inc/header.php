<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
function isActive($page) {
  $current = basename($_SERVER['PHP_SELF']);
  return $current === $page ? 'nav-link active' : 'nav-link';
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo isset($title) ? $title . ' | Citate Motivaționale' : 'Citate Motivaționale'; ?></title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body id="top">
  <header class="site-header">
    <div class="container header-inner">
      <a class="brand" href="index.php">
        <div class="logo">🌟</div>
        <div class="brand-text">
          <h1>Citate Motivaționale</h1>
          <small>Inspirație zilnică — idei care schimbă</small>
        </div>
      </a>

      <nav class="main-nav">
    <a class="<?php echo isActive('index.php'); ?>" href="index.php">Acasă</a>
    <a class="<?php echo isActive('citate.php'); ?>" href="citate.php">Citate</a>
    <a class="<?php echo isActive('gallery.php'); ?>" href="gallery.php">Galerie</a>
    <a class="<?php echo isActive('despre.php'); ?>" href="despre.php">Despre</a>
    <a class="<?php echo isActive('contact.php'); ?>" href="contact.php">Contact</a>

    <?php if (!isset($_SESSION['logged'])): ?>
        <a class="<?php echo isActive('login.php'); ?>" href="login.php">Login</a>
        <a class="<?php echo isActive('register.php'); ?>" href="register.php">Register</a>

    <?php else: ?>
        <a>Salut, <?php echo $_SESSION['user']; ?>!</a>
        <a class="<?php echo isActive('myaccount.php'); ?>" href="myaccount.php">Contul meu</a>
        <a href="logout.php">Logout</a>
    <?php endif; ?>
</nav>


      <button class="burger" aria-label="Meniu">☰</button>
    </div>
  </header>

  <main class="site-main container">
