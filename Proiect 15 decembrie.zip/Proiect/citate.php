<?php
$title = "Citate";
include __DIR__ . '/inc/header.php';
include __DIR__ . '/inc/db.php';

if (!isset($_SESSION['favorites'])) $_SESSION['favorites'] = [];

if (isset($_GET['fav_add'])) {
    $id = intval($_GET['fav_add']);
    if (!in_array($id, $_SESSION['favorites'])) $_SESSION['favorites'][] = $id;
    header('Location: citate.php');
    exit;
}
if (isset($_GET['fav_remove'])) {
    $id = intval($_GET['fav_remove']);
    $_SESSION['favorites'] = array_filter($_SESSION['favorites'], fn($v)=>$v!==$id);
    header('Location: citate.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$view = $_GET['view'] ?? '';

$whereClause = "WHERE 1=1";
$params = [];
$types = "";

if ($search !== '') {
    $whereClause .= " AND (text LIKE ? OR autor LIKE ?)";
    $searchTerm = "%" . $search . "%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "ss";
}

if ($view === 'favorites') {
    if (!empty($_SESSION['favorites'])) {
        $fav_ids = implode(',', array_map('intval', $_SESSION['favorites']));
        $whereClause .= " AND id IN ($fav_ids)";
    } else {
        $whereClause .= " AND 1=0";
    }
}

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

$countSql = "SELECT COUNT(*) as total FROM citate $whereClause";
$stmt = $conn->prepare($countSql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalResult = $stmt->get_result()->fetch_assoc();
$totalFiltered = $totalResult['total'];
$pages = max(1, ceil($totalFiltered / $perPage));

$sql = "SELECT * FROM citate $whereClause ORDER BY id DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}
?>

<section class="list-header">
  <h2>Toate citatele</h2>
  <form class="search-form" method="get" action="citate.php">
    <input name="q" id="search-input" placeholder="Caută (ex: succes, Steve Jobs)" value="<?php echo htmlspecialchars($search); ?>">
    <?php if($view === 'favorites'): ?>
      <input type="hidden" name="view" value="favorites">
    <?php endif; ?>
    <button class="btn" type="submit">Caută</button>
    <a href="citate.php" class="btn ghost">Resetează</a>
  </form>
</section>

<section class="quote-list" id="quote-list">
  <?php if(empty($items)): ?>
    <div class="empty card">Nu s-au găsit citate în baza de date.</div>
  <?php else: ?>
    <?php foreach($items as $row): ?>
      <article class="quote-card card">
        <p class="qtext">"<?php echo htmlspecialchars($row['text']); ?>"</p>
        <div class="autor" style="text-align:right; font-weight:bold; margin-bottom:10px;">
            — <?php echo htmlspecialchars($row['autor'] ?? 'Anonim'); ?>
        </div>
        
        <div class="quote-actions">
          <a class="btn small" href="detalii.php?id=<?php echo $row['id']; ?>">Detalii</a>

          <?php if(in_array($row['id'], $_SESSION['favorites'] ?? [])): ?>
            <a class="btn small danger" href="citate.php?fav_remove=<?php echo $row['id']; ?>">Elimină Fav</a>
          <?php else: ?>
            <a class="btn small" href="citate.php?fav_add=<?php echo $row['id']; ?>">Adaugă Fav</a>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<?php if($pages > 1): ?>
  <nav class="pagination">
    <?php for($p=1;$p<=$pages;$p++): ?>
      <a class="page-link <?php echo $p==$page ? 'active' : ''; ?>" 
         href="citate.php?page=<?php echo $p; ?>&q=<?php echo urlencode($search); ?><?php echo $view==='favorites' ? '&view=favorites':''; ?>">
         <?php echo $p; ?>
      </a>
    <?php endfor; ?>
  </nav>
<?php endif; ?>

<?php include __DIR__ . '/inc/footer.php'; ?>