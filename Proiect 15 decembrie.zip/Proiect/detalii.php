<?php
$title = "Detalii citat";
include __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/db.php'; 

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $conn->prepare("SELECT * FROM citate WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='container'><div class='notice danger'>Citat invalid sau inexistent.</div></div>";
    include __DIR__ . '/inc/footer.php';
    exit;
}

$q = $result->fetch_assoc();
?>

<section class="detail">
  <div class="detail-card card">
    <p class="qtext large">"<?php echo htmlspecialchars($q['text']); ?>"</p>
    <div class="autor-large" style="text-align:right; font-size:1.2em; font-weight:bold; margin-bottom:20px;">
        — <?php echo htmlspecialchars($q['autor']); ?>
    </div>

    <div class="meta">
      <span>ID Bază de Date: <?php echo $q['id']; ?></span>
      <span>Dată adăugare: <?php echo $q['data_adaugarii']; ?></span>
    </div>

    <div class="quote-actions">
      <a class="btn" href="citate.php">Înapoi la listă</a>
      
      <?php if(in_array($q['id'], $_SESSION['favorites'] ?? [])): ?>
        <a class="btn danger" href="citate.php?fav_remove=<?php echo $q['id']; ?>">Elimină din favorite</a>
      <?php else: ?>
        <a class="btn" href="citate.php?fav_add=<?php echo $q['id']; ?>">Adaugă la favorite</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/inc/footer.php'; ?>