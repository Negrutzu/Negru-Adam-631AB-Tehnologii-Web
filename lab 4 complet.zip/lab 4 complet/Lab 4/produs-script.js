document.addEventListener('DOMContentLoaded', () => {
  const detalii = document.getElementById('detalii');
  const btn = document.getElementById('btnDetalii');
  const spanData = document.getElementById('dataProdus');

  const luni = ['Ianuarie','Februarie','Martie','Aprilie','Mai','Iunie','Iulie','August','Septembrie','Octombrie','Noiembrie','Decembrie'];

  function formatData(d){
    return `${d.getDate()} ${luni[d.getMonth()]} ${d.getFullYear()}`;
  }

  detalii.classList.add('ascuns');

  const azi = new Date();
  spanData.textContent = formatData(azi);

  btn.addEventListener('click', () => {
    detalii.classList.toggle('ascuns');
    btn.textContent = detalii.classList.contains('ascuns')
      ? 'Afișează detalii'
      : 'Ascunde detalii';
  });
});
