document.addEventListener('DOMContentLoaded', () => {
const input = document.getElementById('inputActivitate');
const btn = document.getElementById('btnAdauga');
const ul = document.getElementById('listaActivitati');


const luni = ['Ianuarie','Februarie','Martie','Aprilie','Mai','Iunie','Iulie','August','Septembrie','Octombrie','Noiembrie','Decembrie'];


function formatData(d) {
const zi = d.getDate();
const luna = luni[d.getMonth()];
const an = d.getFullYear();
return `${zi} ${luna} ${an}`;
}


btn.addEventListener('click', () => {
const text = input.value.trim();
if (!text) return; // nu adăugăm element gol


const li = document.createElement('li');
const data = new Date();
li.textContent = `${text} – adăugată la: ${formatData(data)}`;


ul.appendChild(li);
input.value = '';
input.focus();
});


input.addEventListener('keypress', (e) => {
if (e.key === 'Enter') btn.click();
});
});