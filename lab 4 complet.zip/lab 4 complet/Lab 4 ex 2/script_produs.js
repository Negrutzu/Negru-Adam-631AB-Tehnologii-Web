document.addEventListener("DOMContentLoaded", function () {

    const detalii = document.getElementById("detalii");
    const btn = document.getElementById("btnDetalii");
    const dataProdus = document.getElementById("dataProdus");

    
    detalii.classList.add("ascuns");

    const azi = new Date();
    const zi = azi.getDate();
    const luni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];
    const luna = luni[azi.getMonth()];
    const anul = azi.getFullYear();

    dataProdus.textContent = `${zi} ${luna} ${anul}`;

    btn.addEventListener("click", function () {
        detalii.classList.toggle("ascuns");

        if (detalii.classList.contains("ascuns")) {
            btn.textContent = "Afișează detalii";
        } else {
            btn.textContent = "Ascunde detalii";
        }
    });

});
