<?php
$title = "Acasă";
include __DIR__ . '/inc/header.php';
include __DIR__ . '/inc/quotes_data.php';
// featured (3 random)
$randKeys = array_rand($QUOTES, 3);
$featured = array_map(fn($k) => $QUOTES[$k], (array)$randKeys);
?>
<section class="layout-grid">
  <header class="hero">
    <div class="hero-inner card">
      <h2>Găsește cuvintele care te ridică azi.</h2>
      <p>O colecție curată de citate motivaționale atent selectate — inspiră, meditează, acționează.</p>
      <div class="hero-cta">
        <a class="btn primary" href="citate.php">Vezi toate citatele</a>
        <a class="btn ghost" href="contact.php">Trimite un citat</a>
      </div>
    </div>
    <aside class="hero-aside">
      <?php foreach($featured as $f): ?>
        <div class="card featured-quote">
          <p class="qtext"><?php echo htmlspecialchars($f); ?></p>
        </div>
      <?php endforeach; ?>
    </aside>
  </header>

  <main class="main-content">
    <section class="card products">
      <h3>Secțiune demonstrativă (Flexbox)</h3>
      <p>Această secțiune demonstrează cerința de layout cu Flexbox pentru carduri.</p>
      <div class="product-row">
        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder1.jpg')"></div>
          <h4>Inspirație zilnică</h4>
          <p>Colecție vastă de cuvinte care te împing înainte.</p>
        </div>

        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder2.jpg')"></div>
          <h4>Favorite</h4>
          <p>Salvează-ți citatele preferate pentru a reveni rapid la ele.</p>
        </div>

        <div class="product-card card">
          <div class="product-img" style="background-image:url('assets/images/placeholder3.jpg')"></div>
          <h4>Trimite un citat</h4>
          <p>Ai un citat preferat? Trimite-l prin formularul de contact.</p>
        </div>
      </div>
    </section>
  </main>

  <aside class="sidebar">
    <div class="card">
      <h4>Despre autor</h4>
      <p>Adam Negru — pasionat de tehnologie și design.</p>
    </div>
    <div class="card">
      <h4>Citate populare</h4>
      <ul>
        <?php for($i=0;$i<5;$i++): ?>
          <li><?php echo htmlspecialchars($QUOTES[$i]); ?></li>
        <?php endfor; ?>
      </ul>
    </div>
  </aside>

  <footer class="page-footer card">
    <p>Pagina creată pentru proiectul de Web — include Grid, Flexbox, Responsive.</p>
  </footer>
</section>

<?php include __DIR__ . '/inc/footer.php'; ?>
