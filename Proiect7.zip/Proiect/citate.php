<?php
$title = "Citate";
include __DIR__ . '/inc/header.php';
include __DIR__ . '/inc/quotes_data.php';

if (!isset($_SESSION['favorites'])) $_SESSION['favorites'] = [];
if (isset($_GET['fav_add'])) {
  $id = intval($_GET['fav_add']);
  if (!in_array($id, $_SESSION['favorites'])) $_SESSION['favorites'][] = $id;
  header('Location: citate.php');
  exit;
}
if (isset($_GET['fav_remove'])) {
  $id = intval($_GET['fav_remove']);
  $_SESSION['favorites'] = array_filter($_SESSION['favorites'], fn($v)=>$v!==$id);
  header('Location: citate.php');
  exit;
}

$all = $QUOTES;
$search = trim($_GET['q'] ?? '');
if ($search !== '') {
  $all = array_filter($all, fn($q)=>stripos($q,$search)!==false);
}
$view = $_GET['view'] ?? '';
if ($view === 'favorites') {
  $all = array_intersect_key($QUOTES, array_flip($_SESSION['favorites'] ?? []));
}

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;
$totalFiltered = count($all);
$pages = max(1, ceil($totalFiltered/$perPage));
$start = ($page-1)*$perPage;
$items = array_slice(array_values($all), $start, $perPage);
?>

<section class="list-header">
  <h2>Toate citatele</h2>
  <form class="search-form" method="get" action="citate.php" id="server-search-form">
    <input name="q" id="search-input" placeholder="Caută citate (ex: succes, curaj)" value="<?php echo htmlspecialchars($search); ?>">
    <?php if($view === 'favorites'): ?>
      <input type="hidden" name="view" value="favorites">
    <?php endif; ?>
    <button class="btn" type="submit">Caută</button>
    <button class="btn ghost" type="button" id="client-filter-btn">Filtrează local</button>
  </form>
</section>

<section class="quote-list" id="quote-list">
  <?php if(empty($items)): ?>
    <div class="empty card">Nu s-au găsit citate.</div>
  <?php else: ?>
    <?php foreach($items as $idx => $q): $id = $start + $idx; ?>
      <article class="quote-card card" data-quote="<?php echo htmlspecialchars($q); ?>" data-id="<?php echo $id; ?>">
        <p class="qtext"><?php echo htmlspecialchars($q); ?></p>
        <div class="quote-actions">
          <a class="btn small" href="detalii.php?id=<?php echo $id; ?>" data-id="<?php echo $id; ?>">Detalii</a>

          <?php if(in_array($id, $_SESSION['favorites'] ?? [])): ?>
            <a class="btn small danger fav-toggle" data-id="<?php echo $id; ?>" href="citate.php?fav_remove=<?php echo $id; ?>">Elimină din favorite</a>
          <?php else: ?>
            <a class="btn small fav-toggle" data-id="<?php echo $id; ?>" href="citate.php?fav_add=<?php echo $id; ?>">Adaugă la favorite</a>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<?php if($pages > 1): ?>
  <nav class="pagination">
    <?php for($p=1;$p<=$pages;$p++): ?>
      <a class="page-link <?php echo $p==$page ? 'active' : ''; ?>" href="citate.php?page=<?php echo $p; ?><?php echo $search ? '&q='.urlencode($search):''; ?><?php echo $view==='favorites' ? '&view=favorites':''; ?>"><?php echo $p; ?></a>
    <?php endfor; ?>
  </nav>
<?php endif; ?>

<?php include __DIR__ . '/inc/footer.php'; ?>
