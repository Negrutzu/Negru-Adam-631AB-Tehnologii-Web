-- auto-generated definition
create schema citate_db collate utf8mb4_0900_ai_ci;

